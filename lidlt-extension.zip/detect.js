/**
 * Marcador en el mundo MAIN.
 *
 * `window.__lidlt_ext` se mantiene por compatibilidad: es lo que comprueban las
 * versiones de la web anteriores a la detección de versión. La versión en sí la
 * publica version.js en el DOM, porque `chrome.runtime` no existe aquí.
 */
window.__lidlt_ext = true;
