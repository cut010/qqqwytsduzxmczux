// Marker so the website can detect the extension is installed
window.__lidlt_ext = true;
