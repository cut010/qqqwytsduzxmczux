/**
 * Publica la versión instalada para que la web pueda compararla.
 *
 * Este script corre en el mundo AISLADO, que es el único donde existe
 * `chrome.runtime`. El marcador va al DOM (`documentElement.dataset`) porque es
 * lo único que comparten el mundo aislado, el mundo MAIN y la propia página.
 *
 * No se hardcodea la versión: se lee del manifiesto, así que basta con subirla
 * en manifest.json y no hay dos sitios que puedan desincronizarse.
 */
(() => {
  try {
    const { version } = chrome.runtime.getManifest();
    const root = document.documentElement;
    root.dataset.lidltExt = version;

    // Aviso para el código que ya se esté ejecutando en la página.
    document.dispatchEvent(new CustomEvent('lidlt-ext', { detail: { version } }));
  } catch {
    /* Si la API no está disponible, la web lo tratará como instalación antigua. */
  }
})();
